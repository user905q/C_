﻿namespace LAB_1
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdd = new Button();
            btnDelete = new Button();
            btnClear = new Button();
            txtDriver = new TextBox();
            txtTime = new TextBox();
            lstResults = new ListBox();
            cmbCar = new ComboBox();
            cmbTrack = new ComboBox();
            lblStatus = new Label();
            txtDriver_lbl = new Label();
            cmbCar_lbl = new Label();
            cmbTrack_lbl = new Label();
            txtTime_lbl = new Label();
            lstResults_lbl = new Label();
            title = new Label();
            subtitle = new Label();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(955, 508);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(143, 23);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Добавить результат";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(1132, 508);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(143, 23);
            btnDelete.TabIndex = 1;
            btnDelete.Text = "Удалить выбранное";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(1312, 508);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(143, 23);
            btnClear.TabIndex = 2;
            btnClear.Text = "Очистить поля";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // txtDriver
            // 
            txtDriver.Location = new Point(629, 260);
            txtDriver.Name = "txtDriver";
            txtDriver.Size = new Size(207, 23);
            txtDriver.TabIndex = 3;
            txtDriver.TextChanged += txtDriver_TextChanged;
            // 
            // txtTime
            // 
            txtTime.Location = new Point(629, 516);
            txtTime.Name = "txtTime";
            txtTime.Size = new Size(207, 23);
            txtTime.TabIndex = 4;
            txtTime.TextChanged += txtTime_TextChanged;
            // 
            // lstResults
            // 
            lstResults.FormattingEnabled = true;
            lstResults.Location = new Point(955, 287);
            lstResults.Name = "lstResults";
            lstResults.Size = new Size(550, 199);
            lstResults.TabIndex = 5;
            lstResults.SelectedIndexChanged += lstResults_SelectedIndexChanged;
            // 
            // cmbCar
            // 
            cmbCar.FormattingEnabled = true;
            cmbCar.Location = new Point(629, 344);
            cmbCar.Name = "cmbCar";
            cmbCar.Size = new Size(207, 23);
            cmbCar.TabIndex = 6;
            cmbCar.SelectedIndexChanged += cmbCar_SelectedIndexChanged;
            // 
            // cmbTrack
            // 
            cmbTrack.FormattingEnabled = true;
            cmbTrack.Location = new Point(629, 429);
            cmbTrack.Name = "cmbTrack";
            cmbTrack.Size = new Size(207, 23);
            cmbTrack.TabIndex = 7;
            cmbTrack.SelectedIndexChanged += cmbTrack_SelectedIndexChanged;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(960, 559);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(97, 15);
            lblStatus.TabIndex = 8;
            lblStatus.Text = "Всего записей: 0";
            lblStatus.Click += lblStatus_Click;
            // 
            // txtDriver_lbl
            // 
            txtDriver_lbl.AutoSize = true;
            txtDriver_lbl.Location = new Point(446, 268);
            txtDriver_lbl.Name = "txtDriver_lbl";
            txtDriver_lbl.Size = new Size(42, 15);
            txtDriver_lbl.TabIndex = 9;
            txtDriver_lbl.Text = "Пилот";
            // 
            // cmbCar_lbl
            // 
            cmbCar_lbl.AutoSize = true;
            cmbCar_lbl.Location = new Point(446, 352);
            cmbCar_lbl.Name = "cmbCar_lbl";
            cmbCar_lbl.Size = new Size(76, 15);
            cmbCar_lbl.TabIndex = 10;
            cmbCar_lbl.Text = "Автомобиль";
            // 
            // cmbTrack_lbl
            // 
            cmbTrack_lbl.AutoSize = true;
            cmbTrack_lbl.Location = new Point(446, 432);
            cmbTrack_lbl.Name = "cmbTrack_lbl";
            cmbTrack_lbl.Size = new Size(44, 15);
            cmbTrack_lbl.TabIndex = 11;
            cmbTrack_lbl.Text = "Трасса";
            // 
            // txtTime_lbl
            // 
            txtTime_lbl.AutoSize = true;
            txtTime_lbl.Location = new Point(446, 516);
            txtTime_lbl.Name = "txtTime_lbl";
            txtTime_lbl.Size = new Size(54, 15);
            txtTime_lbl.TabIndex = 12;
            txtTime_lbl.Text = "Время, с";
            // 
            // lstResults_lbl
            // 
            lstResults_lbl.AutoSize = true;
            lstResults_lbl.Location = new Point(955, 239);
            lstResults_lbl.Name = "lstResults_lbl";
            lstResults_lbl.Size = new Size(69, 15);
            lstResults_lbl.TabIndex = 13;
            lstResults_lbl.Text = "Результаты";
            // 
            // title
            // 
            title.AutoSize = true;
            title.Location = new Point(145, 29);
            title.Name = "title";
            title.Size = new Size(144, 15);
            title.TabIndex = 14;
            title.Text = "Учебный автосимулятор";
            // 
            // subtitle
            // 
            subtitle.AutoSize = true;
            subtitle.Location = new Point(145, 125);
            subtitle.Name = "subtitle";
            subtitle.Size = new Size(201, 15);
            subtitle.TabIndex = 15;
            subtitle.Text = "Первый прототип журнала заездов";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1603, 839);
            Controls.Add(subtitle);
            Controls.Add(title);
            Controls.Add(lstResults_lbl);
            Controls.Add(txtTime_lbl);
            Controls.Add(cmbTrack_lbl);
            Controls.Add(cmbCar_lbl);
            Controls.Add(txtDriver_lbl);
            Controls.Add(lblStatus);
            Controls.Add(cmbTrack);
            Controls.Add(cmbCar);
            Controls.Add(lstResults);
            Controls.Add(txtTime);
            Controls.Add(txtDriver);
            Controls.Add(btnClear);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Name = "MainForm";
            Text = "Учебный Автосимулятор";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAdd;
        private Button btnDelete;
        private Button btnClear;
        private TextBox txtDriver;
        private TextBox txtTime;
        private ListBox lstResults;
        private ComboBox cmbCar;
        private ComboBox cmbTrack;
        private Label lblStatus;
        private Label txtDriver_lbl;
        private Label cmbCar_lbl;
        private Label cmbTrack_lbl;
        private Label txtTime_lbl;
        private Label lstResults_lbl;
        private Label title;
        private Label subtitle;
    }
}
