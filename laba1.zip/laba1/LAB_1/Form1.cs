using System.Data;

namespace LAB_1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            // Add to combox
            cmbCar.Items.Add("Prototype");
            cmbCar.Items.Add("Sport");
            cmbCar.Items.Add("Classic");

            cmbTrack.Items.Add("Учебный овал");
            cmbTrack.Items.Add("Городское кольцо");
            cmbTrack.Items.Add("Горная трасса");

            cmbCar.SelectedIndex = 0;
            cmbTrack.SelectedIndex = 0;
            Update_lblStatus();


            title.Font = new Font(title.Font.FontFamily, 45);
            subtitle.Font = new Font(subtitle.Font.FontFamily, 25);

            // Label FontSize
            txtDriver_lbl.Font = new Font(txtDriver_lbl.Font.FontFamily, 16);
            cmbCar_lbl.Font = new Font(cmbCar_lbl.Font.FontFamily, 16);
            cmbTrack_lbl.Font = new Font(cmbTrack_lbl.Font.FontFamily, 16);
            txtTime_lbl.Font = new Font(txtTime_lbl.Font.FontFamily, 16);
            lstResults_lbl.Font = new Font(lstResults_lbl.Font.FontFamily, 18);
            lblStatus.Font = new Font(lblStatus.Font.FontFamily, 18);


            // textbox FontSise
            txtDriver.Font = new Font(txtDriver.Font.FontFamily, 17);
            cmbCar.Font = new Font(cmbCar.Font.FontFamily, 17);
            cmbTrack.Font = new Font(cmbTrack.Font.FontFamily, 17);
            txtTime.Font = new Font(txtTime.Font.FontFamily, 17);
            lstResults.Font = new Font(lstResults.Font.FontFamily, 20);

            // button FontSize
            btnAdd.Font = new Font(btnAdd.Font.FontFamily, 18);
            btnAdd.Size = new Size(btnAdd.Width + 30, btnAdd.Height + 20);

            btnDelete.Font = new Font(btnDelete.Font.FontFamily, 18);
            btnDelete.Size = new Size(btnDelete.Width + 30, btnDelete.Height + 20);

            btnClear.Font = new Font(btnClear.Font.FontFamily, 18);
            btnClear.Size = new Size(btnClear.Width + 30, btnClear.Height + 20);



        }

        private void Update_lblStatus()
        {
            lblStatus.Text = $"Добавлено всего записей: {lstResults.Items.Count}";
        }

        private void ClnInp() 
        {
            txtDriver.Clear();
            txtTime.Clear();
            cmbCar.SelectedIndex = 0;
            cmbTrack.SelectedIndex = 0;
            lblStatus.ForeColor = System.Drawing.SystemColors.ControlText;
            txtDriver.Focus();
            lblStatus.Text = "Поля очищены";
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            string driver = txtDriver.Text.Trim();

            if (driver.Length == 0)
            {
                lblStatus.Text = "Введите имя пилота";
                txtDriver.Focus();
                return;
            }

            if (!int.TryParse(txtTime.Text.Trim(), out int time))
            {
                lblStatus.Text = "Введите целое число";
                lblStatus.ForeColor = System.Drawing.Color.Red;
                txtTime.Focus();
                return;
            }

            if (time < 30 || time > 600) 
            {
                lblStatus.Text = "Диапазон: 30 - 600 секунд";
                lblStatus.ForeColor= System.Drawing.Color.Red;
                txtTime.Focus();
                return;
            }

            string result = $"{driver} | {cmbCar.SelectedIndex} | {cmbTrack.SelectedIndex} |{time}";

            lstResults.Items.Add(result);

            lblStatus.Text = "Запись добавлена";
            lblStatus.ForeColor = System.Drawing.Color.Green;


            ClnInp();
            Update_lblStatus();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lstResults.SelectedIndex < 0) 
            {
                lblStatus.Text = "Выберите строку для удаления";
                lblStatus.ForeColor = System.Drawing.Color.Red;
                return;
            }

            lstResults.Items.RemoveAt(lstResults.SelectedIndex);

            lblStatus.ForeColor = System.Drawing.Color.Black;
            Update_lblStatus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClnInp();
        }



        private void txtDriver_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbCar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        
        private void cmbTrack_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtTime_TextChanged(object sender, EventArgs e)
        {

        }

        private void lstResults_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }


    }
}
