﻿namespace laba2
{
    public static class RaceRules
    {
        public const int MinLapSeconds = 30;
        public const int MaxLapSeconds = 600;

        public static readonly string[] Cars = { "Street", "Sport", "Prototype" };
        public static readonly string[] Tracks = { "Учебный овал", "Городское кольцо", "Спринт" };

        public static void Validate(RaceResult row)
        {
            if (row == null)
                throw new ArgumentException("Запись отсутствует");

            if (string.IsNullOrWhiteSpace(row.Driver))
                throw new ArgumentException("Введите имя пилота");

            if (Array.IndexOf(Cars, row.Car) < 0)
                throw new ArgumentException("Неизвестный автомобиль");

            if (Array.IndexOf(Tracks, row.Track) < 0)
                throw new ArgumentException("Неизвестная трасса");

            if (row.LapSeconds < MinLapSeconds || row.LapSeconds > MaxLapSeconds)
                throw new ArgumentException($"Диапазон: {MinLapSeconds} - {MaxLapSeconds} секунд");
        }

        public static void ValidateImport(List<RaceResult> rows)
        {
            if (rows == null)
                throw new ArgumentException("Копия не читается");

            var ids = new List<long>();
            foreach (var row in rows)
            {
                Validate(row);
                if (row.Id <= 0)
                    throw new ArgumentException("Id должен быть положительным");
                if (ids.Contains(row.Id))
                    throw new ArgumentException($"Повтор Id: {row.Id}");
                ids.Add(row.Id);
            }
        }
    }
}
