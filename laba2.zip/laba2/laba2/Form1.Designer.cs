﻿namespace laba2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtDriver = new TextBox();
            cmbCar = new ComboBox();
            cmbTrack = new ComboBox();
            txtSeconds = new TextBox();
            txtSearch = new TextBox();
            cmbTrackFilter = new ComboBox();
            gridResults = new DataGridView();
            source = new BindingSource(components);
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnClear = new Button();
            btnReload = new Button();
            btnFilter = new Button();
            btnResetFilter = new Button();
            btnSaveJson = new Button();
            btnLoadJson = new Button();
            btnSaveXml = new Button();
            btnLoadXml = new Button();
            lblStatus = new Label();
            lblStorage = new Label();
            txtSrch = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)gridResults).BeginInit();
            ((System.ComponentModel.ISupportInitialize)source).BeginInit();
            SuspendLayout();
            // 
            // txtDriver
            // 
            txtDriver.Location = new Point(1064, 129);
            txtDriver.Name = "txtDriver";
            txtDriver.Size = new Size(177, 23);
            txtDriver.TabIndex = 0;
            // 
            // cmbCar
            // 
            cmbCar.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCar.FormattingEnabled = true;
            cmbCar.Items.AddRange(new object[] { "Street", "Sport", "Prototype" });
            cmbCar.Location = new Point(1064, 192);
            cmbCar.Name = "cmbCar";
            cmbCar.Size = new Size(177, 23);
            cmbCar.TabIndex = 1;
            // 
            // cmbTrack
            // 
            cmbTrack.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTrack.FormattingEnabled = true;
            cmbTrack.Items.AddRange(new object[] { "Учебный овал", "Городское кольцо", "Спринт" });
            cmbTrack.Location = new Point(1064, 258);
            cmbTrack.Name = "cmbTrack";
            cmbTrack.Size = new Size(177, 23);
            cmbTrack.TabIndex = 2;
            // 
            // txtSeconds
            // 
            txtSeconds.Location = new Point(1064, 340);
            txtSeconds.Name = "txtSeconds";
            txtSeconds.Size = new Size(177, 23);
            txtSeconds.TabIndex = 3;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(1559, 263);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(160, 23);
            txtSearch.TabIndex = 4;
            // 
            // cmbTrackFilter
            // 
            cmbTrackFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTrackFilter.FormattingEnabled = true;
            cmbTrackFilter.Items.AddRange(new object[] { "Все трассы", "Учебный овал", "Городское кольцо", "Спринт" });
            cmbTrackFilter.Location = new Point(1557, 340);
            cmbTrackFilter.Name = "cmbTrackFilter";
            cmbTrackFilter.Size = new Size(162, 23);
            cmbTrackFilter.TabIndex = 5;
            // 
            // gridResults
            // 
            gridResults.AllowUserToAddRows = false;
            gridResults.AutoGenerateColumns = false;
            gridResults.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridResults.DataSource = source;
            gridResults.Location = new Point(12, 12);
            gridResults.MultiSelect = false;
            gridResults.Name = "gridResults";
            gridResults.ReadOnly = true;
            gridResults.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridResults.Size = new Size(871, 321);
            gridResults.TabIndex = 6;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(926, 422);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(165, 23);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "Добавить";
            btnAdd.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(1140, 422);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(165, 23);
            btnUpdate.TabIndex = 8;
            btnUpdate.Text = "Сохранить правку";
            btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(926, 489);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(165, 23);
            btnDelete.TabIndex = 9;
            btnDelete.Text = "Удалить";
            btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(926, 552);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(165, 23);
            btnClear.TabIndex = 10;
            btnClear.Text = "Очистить";
            btnClear.UseVisualStyleBackColor = true;
            // 
            // btnReload
            // 
            btnReload.Location = new Point(466, 659);
            btnReload.Name = "btnReload";
            btnReload.Size = new Size(146, 23);
            btnReload.TabIndex = 11;
            btnReload.Text = "Обновить";
            btnReload.UseVisualStyleBackColor = true;
            // 
            // btnFilter
            // 
            btnFilter.Location = new Point(1557, 422);
            btnFilter.Name = "btnFilter";
            btnFilter.Size = new Size(190, 23);
            btnFilter.TabIndex = 12;
            btnFilter.Text = "Найти";
            btnFilter.UseVisualStyleBackColor = true;
            // 
            // btnResetFilter
            // 
            btnResetFilter.Location = new Point(1557, 491);
            btnResetFilter.Name = "btnResetFilter";
            btnResetFilter.Size = new Size(190, 23);
            btnResetFilter.TabIndex = 13;
            btnResetFilter.Text = "Сброс поиска";
            btnResetFilter.UseVisualStyleBackColor = true;
            // 
            // btnSaveJson
            // 
            btnSaveJson.Location = new Point(30, 388);
            btnSaveJson.Name = "btnSaveJson";
            btnSaveJson.Size = new Size(143, 23);
            btnSaveJson.TabIndex = 14;
            btnSaveJson.Text = "В JSON";
            btnSaveJson.UseVisualStyleBackColor = true;
            // 
            // btnLoadJson
            // 
            btnLoadJson.Location = new Point(30, 461);
            btnLoadJson.Name = "btnLoadJson";
            btnLoadJson.Size = new Size(143, 23);
            btnLoadJson.TabIndex = 15;
            btnLoadJson.Text = "Из JSON";
            btnLoadJson.UseVisualStyleBackColor = true;
            // 
            // btnSaveXml
            // 
            btnSaveXml.Location = new Point(234, 388);
            btnSaveXml.Name = "btnSaveXml";
            btnSaveXml.Size = new Size(153, 23);
            btnSaveXml.TabIndex = 16;
            btnSaveXml.Text = "В XML";
            btnSaveXml.UseVisualStyleBackColor = true;
            // 
            // btnLoadXml
            // 
            btnLoadXml.Location = new Point(234, 461);
            btnLoadXml.Name = "btnLoadXml";
            btnLoadXml.Size = new Size(153, 23);
            btnLoadXml.TabIndex = 17;
            btnLoadXml.Text = "Из XML";
            btnLoadXml.UseVisualStyleBackColor = true;
            // 
            // lblStatus
            // 
            lblStatus.Location = new Point(30, 631);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(384, 86);
            lblStatus.TabIndex = 18;
            // 
            // lblStorage
            // 
            lblStorage.Location = new Point(30, 749);
            lblStorage.Name = "lblStorage";
            lblStorage.Size = new Size(927, 102);
            lblStorage.TabIndex = 19;
            // 
            // txtSrch
            // 
            txtSrch.AutoSize = true;
            txtSrch.Location = new Point(1621, 192);
            txtSrch.Name = "txtSrch";
            txtSrch.Size = new Size(42, 15);
            txtSrch.TabIndex = 20;
            txtSrch.Text = "Посик";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(1124, 68);
            label1.Name = "label1";
            label1.Size = new Size(46, 15);
            label1.TabIndex = 21;
            label1.Text = "Запись";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(935, 129);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 22;
            label2.Text = "Имя";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(935, 192);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 23;
            label3.Text = "Авто";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(934, 268);
            label4.Name = "label4";
            label4.Size = new Size(32, 15);
            label4.TabIndex = 24;
            label4.Text = "Трек";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(926, 348);
            label5.Name = "label5";
            label5.Size = new Size(42, 15);
            label5.TabIndex = 25;
            label5.Text = "Время";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(1435, 266);
            label6.Name = "label6";
            label6.Size = new Size(31, 15);
            label6.TabIndex = 26;
            label6.Text = "Имя";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(1434, 348);
            label7.Name = "label7";
            label7.Size = new Size(32, 15);
            label7.TabIndex = 27;
            label7.Text = "Трек";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1904, 1041);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtSrch);
            Controls.Add(lblStorage);
            Controls.Add(lblStatus);
            Controls.Add(btnLoadXml);
            Controls.Add(btnSaveXml);
            Controls.Add(btnLoadJson);
            Controls.Add(btnSaveJson);
            Controls.Add(btnResetFilter);
            Controls.Add(btnFilter);
            Controls.Add(btnReload);
            Controls.Add(btnClear);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(gridResults);
            Controls.Add(cmbTrackFilter);
            Controls.Add(txtSearch);
            Controls.Add(txtSeconds);
            Controls.Add(cmbTrack);
            Controls.Add(cmbCar);
            Controls.Add(txtDriver);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Журнал заездов";
            ((System.ComponentModel.ISupportInitialize)gridResults).EndInit();
            ((System.ComponentModel.ISupportInitialize)source).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDriver;
        private ComboBox cmbCar;
        private ComboBox cmbTrack;
        private TextBox txtSeconds;
        private TextBox txtSearch;
        private ComboBox cmbTrackFilter;
        private DataGridView gridResults;
        private BindingSource source;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnClear;
        private Button btnReload;
        private Button btnFilter;
        private Button btnResetFilter;
        private Button btnSaveJson;
        private Button btnLoadJson;
        private Button btnSaveXml;
        private Button btnLoadXml;
        private Label lblStatus;
        private Label lblStorage;
        private Label txtSrch;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
    }
}
