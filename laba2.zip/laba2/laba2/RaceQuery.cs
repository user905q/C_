﻿namespace laba2
{
    public static class RaceQuery
    {
        public static List<RaceResult> Apply(List<RaceResult> all, string text, string track)
        {
            string q = (text ?? "").Trim();
            string t = track ?? "";

            var filtered = all
                .Where(r => q.Length == 0 || r.Driver.Contains(q, StringComparison.OrdinalIgnoreCase))
                .Where(r => t == "Все трассы" || t.Length == 0 || r.Track == t)
                .OrderBy(r => r.Id)
                .ToList();

            return filtered;
        }
    }
}
