﻿using Microsoft.Data.Sqlite;

namespace laba2
{
    public class RaceRepository
    {
        private readonly string _connectionString;

        public RaceRepository(string dbPath)
        {
            var builder = new SqliteConnectionStringBuilder
            {
                DataSource = dbPath
            };
            _connectionString = builder.ToString();
        }

        public void Initialize()
        {
            using var connection = new SqliteConnection(_connectionString);
            connection.Open();

            string sql = @"
                CREATE TABLE IF NOT EXISTS RaceResults (
                    Id INTEGER PRIMARY KEY,
                    Driver TEXT NOT NULL,
                    Car TEXT NOT NULL,
                    Track TEXT NOT NULL,
                    LapSeconds INTEGER NOT NULL CHECK (LapSeconds BETWEEN 30 AND 600)
                );";

            using var command = new SqliteCommand(sql, connection);
            command.ExecuteNonQuery();
        }

        public List<RaceResult> GetAll()
        {
            var list = new List<RaceResult>();

            using var connection = new SqliteConnection(_connectionString);
            connection.Open();

            using var command = new SqliteCommand(
                "SELECT Id, Driver, Car, Track, LapSeconds FROM RaceResults ORDER BY Id",
                connection);

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new RaceResult
                {
                    Id = reader.GetInt64(0),
                    Driver = reader.GetString(1),
                    Car = reader.GetString(2),
                    Track = reader.GetString(3),
                    LapSeconds = reader.GetInt32(4)
                });
            }

            return list;
        }

        public long Add(RaceResult row)
        {
            RaceRules.Validate(row);

            using var connection = new SqliteConnection(_connectionString);
            connection.Open();

            using var command = new SqliteCommand(
                "INSERT INTO RaceResults (Driver, Car, Track, LapSeconds) " +
                "VALUES ($driver, $car, $track, $lap); " +
                "SELECT last_insert_rowid();",
                connection);

            command.Parameters.AddWithValue("$driver", row.Driver);
            command.Parameters.AddWithValue("$car", row.Car);
            command.Parameters.AddWithValue("$track", row.Track);
            command.Parameters.AddWithValue("$lap", row.LapSeconds);

            long newId = (long)command.ExecuteScalar();
            return newId;
        }

        public void Update(RaceResult row)
        {
            RaceRules.Validate(row);

            using var connection = new SqliteConnection(_connectionString);
            connection.Open();

            using var command = new SqliteCommand(
                "UPDATE RaceResults SET Driver=$driver, Car=$car, Track=$track, LapSeconds=$lap WHERE Id=$id",
                connection);

            command.Parameters.AddWithValue("$driver", row.Driver);
            command.Parameters.AddWithValue("$car", row.Car);
            command.Parameters.AddWithValue("$track", row.Track);
            command.Parameters.AddWithValue("$lap", row.LapSeconds);
            command.Parameters.AddWithValue("$id", row.Id);

            command.ExecuteNonQuery();
        }

        public void Delete(long id)
        {
            using var connection = new SqliteConnection(_connectionString);
            connection.Open();

            using var command = new SqliteCommand("DELETE FROM RaceResults WHERE Id=$id", connection);
            command.Parameters.AddWithValue("$id", id);
            command.ExecuteNonQuery();
        }

        public void ReplaceAll(List<RaceResult> rows)
        {
            RaceRules.ValidateImport(rows);

            using var connection = new SqliteConnection(_connectionString);
            connection.Open();

            using var transaction = connection.BeginTransaction();

            using (var delete = new SqliteCommand("DELETE FROM RaceResults", connection, transaction))
            {
                delete.ExecuteNonQuery();
            }

            foreach (var row in rows)
            {
                using var insert = new SqliteCommand(
                    "INSERT INTO RaceResults (Id, Driver, Car, Track, LapSeconds) " +
                    "VALUES ($id, $driver, $car, $track, $lap)",
                    connection, transaction);

                insert.Parameters.AddWithValue("$id", row.Id);
                insert.Parameters.AddWithValue("$driver", row.Driver);
                insert.Parameters.AddWithValue("$car", row.Car);
                insert.Parameters.AddWithValue("$track", row.Track);
                insert.Parameters.AddWithValue("$lap", row.LapSeconds);
                insert.ExecuteNonQuery();
            }

            transaction.Commit();
        }
    }
}
