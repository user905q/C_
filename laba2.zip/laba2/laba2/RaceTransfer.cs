﻿using System.Text.Json;
using System.Xml.Serialization;

namespace laba2
{
    public static class RaceTransfer
    {
        public static void SaveJson(string path, List<RaceResult> rows)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string text = JsonSerializer.Serialize(rows, options);
            File.WriteAllText(path, text);
        }

        public static List<RaceResult> LoadJson(string path)
        {
            string text = File.ReadAllText(path);
            var list = JsonSerializer.Deserialize<List<RaceResult>>(text);
            return list ?? throw new ArgumentException("Копия не читается");
        }

        public static void SaveXml(string path, List<RaceResult> rows)
        {
            var serializer = new XmlSerializer(typeof(List<RaceResult>));
            using var stream = File.Create(path);
            serializer.Serialize(stream, rows);
        }

        public static List<RaceResult> LoadXml(string path)
        {
            var settings = new System.Xml.XmlReaderSettings
            {
                DtdProcessing = System.Xml.DtdProcessing.Prohibit,
                XmlResolver = null
            };

            using var reader = System.Xml.XmlReader.Create(path, settings);
            var serializer = new XmlSerializer(typeof(List<RaceResult>));
            var obj = serializer.Deserialize(reader) as List<RaceResult>;
            return obj ?? throw new ArgumentException("Копия не читается");
        }
    }
}
