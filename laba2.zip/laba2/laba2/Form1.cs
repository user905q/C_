using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace laba2
{
    public partial class Form1 : Form
    {
        private List<RaceResult> allResults = new List<RaceResult>();
        private RaceRepository repository;
        private string dbPath;

        public Form1()
        {
            InitializeComponent();


            label1.Font = new Font(label1.Font.FontFamily, 20);
            label2.Font = new Font(label2.Font.FontFamily, 20);
            label3.Font = new Font(label3.Font.FontFamily, 20);
            label4.Font = new Font(label4.Font.FontFamily, 20);
            label5.Font = new Font(label5.Font.FontFamily, 20);
            label6.Font = new Font(label6.Font.FontFamily, 20);
            label7.Font = new Font(label7.Font.FontFamily, 20);
            txtSrch.Font = new Font(txtSrch.Font.FontFamily, 20);

            lblStatus.Font = new Font(lblStatus.Font.FontFamily, 20);
            lblStorage.Font = new Font(lblStorage.Font.FontFamily, 20);


            txtDriver.Size = new Size(txtDriver.Width + 30, txtDriver.Height + 20);
            cmbCar.Size = new Size(cmbCar.Width + 30, cmbCar.Height + 20);
            cmbTrack.Size = new Size(cmbTrack.Width + 30, cmbTrack.Height + 20);
            txtSeconds.Size = new Size(txtSeconds.Width + 30, txtSeconds.Height + 20);
            txtSearch.Size = new Size(txtSearch.Width + 30, txtSearch.Height + 20);
            cmbTrackFilter.Size = new Size(cmbTrackFilter.Width + 30, cmbTrackFilter.Height + 20);

            btnAdd.Size = new Size(btnAdd.Width + 30, btnAdd.Height + 20);
            btnClear.Size = new Size(btnClear.Width + 30, btnClear.Height + 20);
            btnDelete.Size = new Size(btnDelete.Width + 30, btnDelete.Height + 20);
            btnUpdate.Size = new Size(btnUpdate.Width + 30, btnUpdate.Height + 20);
            btnFilter.Size = new Size(btnFilter.Width + 30, btnFilter.Height + 20);
            btnSaveJson.Size = new Size(btnSaveJson.Width + 30, btnSaveJson.Height + 20);
            btnLoadJson.Size = new Size(btnLoadJson.Width + 30, btnLoadJson.Height + 20);
            btnSaveXml.Size = new Size(btnSaveXml.Width + 30, btnSaveXml.Height + 20);
            btnLoadXml.Size = new Size(btnLoadXml.Width + 30, btnLoadXml.Height + 20);
            gridResults.Size = new Size(gridResults.Width + 30, gridResults.Height + 20);
            cmbCar.Size = new Size(cmbCar.Width + 30, cmbCar.Height + 20);


            txtDriver.Font = new Font(txtDriver.Font.FontFamily, 20);
            cmbCar.Font = new Font(cmbCar.Font.FontFamily, 20);
            cmbTrack.Font = new Font(cmbTrack.Font.FontFamily, 20);
            txtSeconds.Font = new Font(txtSeconds.Font.FontFamily, 20);
            txtSearch.Font = new Font(txtSearch.Font.FontFamily, 20);
            cmbTrackFilter.Font = new Font(cmbTrackFilter.Font.FontFamily, 20);

            btnAdd.Font = new Font(btnAdd.Font.FontFamily, 20);
            btnClear.Font = new Font(btnClear.Font.FontFamily, 20);
            btnDelete.Font = new Font(btnDelete.Font.FontFamily, 20);
            btnUpdate.Font = new Font(btnUpdate.Font.FontFamily, 20);
            btnFilter.Font = new Font(btnFilter.Font.FontFamily, 20);
            btnSaveJson.Font = new Font(btnSaveJson.Font.FontFamily, 20);
            btnLoadJson.Font = new Font(btnLoadJson.Font.FontFamily, 20);
            btnSaveXml.Font = new Font(btnSaveXml.Font.FontFamily, 20);
            btnLoadXml.Font = new Font(btnLoadXml.Font.FontFamily, 20);
            gridResults.Font = new Font(gridResults.Font.FontFamily, 20);

            btnResetFilter.Size = new Size(btnResetFilter.Width + 30, btnResetFilter.Height + 20);
            btnResetFilter.Font = new Font(btnResetFilter.Font.FontFamily, 20);

            btnReload.Font = new Font(btnReload.Font.FontFamily, 20);
            btnReload.Size = new Size(btnReload.Width + 30, btnReload.Height + 20);


            // Комбобоксы: заполняем значениями из правил
            cmbCar.Items.Clear();
            cmbCar.Items.AddRange(RaceRules.Cars);

            cmbTrack.Items.Clear();
            cmbTrack.Items.AddRange(RaceRules.Tracks);

            cmbTrackFilter.Items.Clear();
            cmbTrackFilter.Items.Add("Все трассы");
            cmbTrackFilter.Items.AddRange(RaceRules.Tracks);

            cmbCar.SelectedIndex = 0;
            cmbTrack.SelectedIndex = 0;
            cmbTrackFilter.SelectedIndex = 0;

            // Настройка таблицы 
            gridResults.AutoGenerateColumns = false;
            gridResults.ReadOnly = true;
            gridResults.AllowUserToAddRows = false;
            gridResults.MultiSelect = false;
            gridResults.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridResults.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            gridResults.Columns.Clear();
            gridResults.Columns.Add(new DataGridViewTextBoxColumn { Name = "colId", HeaderText = "Id", DataPropertyName = "Id" });
            gridResults.Columns.Add(new DataGridViewTextBoxColumn { Name = "colDriver", HeaderText = "Пилот", DataPropertyName = "Driver" });
            gridResults.Columns.Add(new DataGridViewTextBoxColumn { Name = "colCar", HeaderText = "Автомобиль", DataPropertyName = "Car" });
            gridResults.Columns.Add(new DataGridViewTextBoxColumn { Name = "colTrack", HeaderText = "Трасса", DataPropertyName = "Track" });
            gridResults.Columns.Add(new DataGridViewTextBoxColumn { Name = "colLapSeconds", HeaderText = "Время, с", DataPropertyName = "LapSeconds" });

            // Подключаем источник
            gridResults.DataSource = source;

            // Привязываем обработчики
            btnAdd.Click += btnAdd_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            btnClear.Click += btnClear_Click;
            btnReload.Click += btnReload_Click;
            btnFilter.Click += btnFilter_Click;
            btnResetFilter.Click += btnResetFilter_Click;
            btnSaveJson.Click += btnSaveJson_Click;
            btnLoadJson.Click += btnLoadJson_Click;
            btnSaveXml.Click += btnSaveXml_Click;
            btnLoadXml.Click += btnLoadXml_Click;
            gridResults.SelectionChanged += gridResults_SelectionChanged;

            // Путь к базе
            string folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "RaceLogLab2");
            Directory.CreateDirectory(folder);
            dbPath = Path.Combine(folder, "racelog.db");
            lblStorage.Text = "База: " + dbPath;


            // Репозиторий и первая загрузка
            repository = new RaceRepository(dbPath);
            repository.Initialize();

            Reload();
        }

        private void Reload()
        {
            try
            {
                allResults = repository.GetAll();
                ApplyFilter();
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Ошибка чтения базы: " + ex.Message;
            }
        }

        private void ApplyFilter()
        {
            string text = txtSearch.Text;
            string track = cmbTrackFilter.SelectedItem as string ?? "Все трассы";

            var filtered = RaceQuery.Apply(allResults, text, track);
            source.DataSource = filtered;
            gridResults.ClearSelection();

            lblStatus.Text = $"Показано: {filtered.Count}. Всего: {allResults.Count}";
        }

        private RaceResult ReadInput(long id)
        {
            string driver = txtDriver.Text.Trim();
            if (driver.Length == 0)
                throw new ArgumentException("Введите имя пилота");

            if (!int.TryParse(txtSeconds.Text.Trim(), out int seconds))
                throw new ArgumentException("Введите целое число");

            if (seconds < RaceRules.MinLapSeconds || seconds > RaceRules.MaxLapSeconds)
                throw new ArgumentException($"Диапазон: {RaceRules.MinLapSeconds} - {RaceRules.MaxLapSeconds} секунд");

            var row = new RaceResult
            {
                Id = id,
                Driver = driver,
                Car = cmbCar.SelectedItem as string ?? "",
                Track = cmbTrack.SelectedItem as string ?? "",
                LapSeconds = seconds
            };

            RaceRules.Validate(row);
            return row;
        }

        private void ClearInput()
        {
            txtDriver.Clear();
            txtSeconds.Clear();
            cmbCar.SelectedIndex = 0;
            cmbTrack.SelectedIndex = 0;
            txtDriver.Focus();
        }

        private RaceResult GetSelected()
        {
            if (gridResults.SelectedRows.Count == 0) return null;
            return gridResults.SelectedRows[0].DataBoundItem as RaceResult;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var row = ReadInput(0);
                repository.Add(row);
                ClearInput();
                Reload();
                lblStatus.Text = "Запись добавлена";
            }
            catch (Exception ex) { lblStatus.Text = ex.Message; }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            var selected = GetSelected();
            if (selected == null) { lblStatus.Text = "Выберите строку для правки"; return; }

            try
            {
                var row = ReadInput(selected.Id);
                repository.Update(row);
                ClearInput();
                Reload();
                lblStatus.Text = "Запись сохранена";
            }
            catch (Exception ex) { lblStatus.Text = ex.Message; }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var selected = GetSelected();
            if (selected == null) { lblStatus.Text = "Выберите строку для удаления"; return; }

            var answer = MessageBox.Show(
                $"Удалить Id={selected.Id}, пилот {selected.Driver}?",
                "Подтверждение", MessageBoxButtons.YesNo);
            if (answer != DialogResult.Yes) return;

            try
            {
                repository.Delete(selected.Id);
                ClearInput();
                Reload();
                lblStatus.Text = "Запись удалена";
            }
            catch (Exception ex) { lblStatus.Text = ex.Message; }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInput();
            gridResults.ClearSelection();
            lblStatus.Text = "Поля очищены";
        }

        private void btnReload_Click(object sender, EventArgs e) { Reload(); }

        private void btnFilter_Click(object sender, EventArgs e) { ApplyFilter(); }

        private void btnResetFilter_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            cmbTrackFilter.SelectedIndex = 0;
            ApplyFilter();
        }

        private void gridResults_SelectionChanged(object sender, EventArgs e)
        {
            var row = GetSelected();
            if (row == null) return;

            txtDriver.Text = row.Driver;
            txtSeconds.Text = row.LapSeconds.ToString();
            cmbCar.SelectedItem = row.Car;
            cmbTrack.SelectedItem = row.Track;
        }

        private void btnSaveJson_Click(object sender, EventArgs e)
        {
            using var dlg = new SaveFileDialog { Filter = "JSON|*.json", FileName = "racelog.json" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            try
            {
                var all = repository.GetAll();
                RaceTransfer.SaveJson(dlg.FileName, all);
                lblStatus.Text = "Сохранено: " + all.Count + " записей";
            }
            catch (Exception ex) { lblStatus.Text = "Ошибка: " + ex.Message; }
        }

        private void btnSaveXml_Click(object sender, EventArgs e)
        {
            using var dlg = new SaveFileDialog { Filter = "XML|*.xml", FileName = "racelog.xml" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            try
            {
                var all = repository.GetAll();
                RaceTransfer.SaveXml(dlg.FileName, all);
                lblStatus.Text = "Сохранено: " + all.Count + " записей";
            }
            catch (Exception ex) { lblStatus.Text = "Ошибка: " + ex.Message; }
        }

        private void btnLoadJson_Click(object sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog { Filter = "JSON|*.json" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            ImportFrom(dlg.FileName, isJson: true);
        }

        private void btnLoadXml_Click(object sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog { Filter = "XML|*.xml" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            ImportFrom(dlg.FileName, isJson: false);
        }

        private void ImportFrom(string path, bool isJson)
        {
            try
            {
                var rows = isJson ? RaceTransfer.LoadJson(path) : RaceTransfer.LoadXml(path);
                RaceRules.ValidateImport(rows);

                int current = allResults.Count;
                var answer = MessageBox.Show(
                    $"Заменить текущий журнал ({current} записей) на {rows.Count} записей?",
                    "Подтверждение", MessageBoxButtons.YesNo);
                if (answer != DialogResult.Yes) return;

                repository.ReplaceAll(rows);
                txtSearch.Clear();
                cmbTrackFilter.SelectedIndex = 0;
                Reload();
                lblStatus.Text = "Журнал восстановлен";
            }
            catch (Exception ex) { lblStatus.Text = "Ошибка импорта: " + ex.Message; }
        }
    }
}